<?php
session_start();

include 'connect.php';

$username = $_POST['username'];
$password = md5($_POST['password']);

$data = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username' AND password = '$password'");
// var_dump($data) ;
$cek = mysqli_num_rows($data);

if ($cek > 0) {
	$_SESSION['username'] = $username;
	$_SESSION['status'] = "login";
	header('location:admin/index.php');
}
else 
{
	header("location:index.php?pesan=gagal");
}

?>