<?php 
$conn = mysqli_connect("localhost","root","","hwstore");
if (!$conn) {
	echo "Anda Belum terkoneksi Database";
}
?>