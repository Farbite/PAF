<!DOCTYPE html>
<html>
<head>
	<title>Halaman Admin FJB Alban dan Farras</title>
</head>
<body>
	<?php 
	session_start();
	if ($_SESSION['status']!="login") {
		header("location:../index.php?pesan=belum_login");
	}
	?>
	<h4>Selamat datang di Halaman Admin <?php echo $_SESSION['username']; ?></h4>

	<a href="logout.php">Logout</a>

</body>
</html>